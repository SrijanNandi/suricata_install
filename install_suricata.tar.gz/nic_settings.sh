#! /bin/sh

### BEGIN INIT INFO
# Provides:          nic card settings
# Required-Stop:
# X-Start-Before:    suricata
# Default-Start:     2 3 4 5
# Default-Stop:
### END INIT INFO

rmmod mlx5_core && modprobe mlx5_core >/dev/null 2>&1;
ifconfig enp94s0f0 down
ifconfig enp94s0f1 down

/sbin/ethtool -A enp94s0f0 rx off tx off >/dev/null 2>&1;
/sbin/ethtool -A enp94s0f1 rx off tx off >/dev/null 2>&1;
/sbin/ethtool -C enp94s0f0 rx-usecs 1 rx-frames 0 >/dev/null 2>&1;
/sbin/ethtool -C enp94s0f1 rx-usecs 1 rx-frames 0 >/dev/null 2>&1;
/sbin/ethtool -L enp94s0f0 combined 40 >/dev/null 2>&1;
/sbin/ethtool -L enp94s0f1 combined 40 >/dev/null 2>&1;
/sbin/ethtool -C enp94s0f0 adaptive-rx off >/dev/null 2>&1;
/sbin/ethtool -C enp94s0f1 adaptive-rx off >/dev/null 2>&1;
/sbin/ethtool -G enp94s0f0 rx 4096 >/dev/null 2>&1;
/sbin/ethtool -G enp94s0f1 rx 4096 >/dev/null 2>&1;
/usr/sbin/set_irq_affinity_bynode.sh 0 enp94s0f0 enp94s0f1 >/dev/null 2>&1;
/sbin/ethtool -X enp94s0f0 hkey 6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A equal 40 >/dev/null 2>&1;
/sbin/ethtool -X enp94s0f1 hkey 6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A:6D:5A equal 40 >/dev/null 2>&1;

for i in rx tx sg tso ufo gso gro lro tx txvlan rxvlan ntuple rxhash; do
       /sbin/ethtool -K enp94s0f0 $i off 2>&1 > /dev/null;
done

for i in rx tx sg tso ufo gso gro lro tx txvlan rxvlan ntuple rxhash; do
       /sbin/ethtool -K enp94s0f1 $i off >/dev/null 2>&1;
done

ifconfig enp94s0f0 up
ifconfig enp94s0f1 up

#for proto in tcp4 udp4 tcp6 udp6; do
#       echo "/sbin/ethtool -N enp59s0 rx-flow-hash $proto sd" 
#       /sbin/ethtool -N enp59s0 rx-flow-hash $proto sd
#done
